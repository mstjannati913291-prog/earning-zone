const express = require('express');
const path = require('path');
const app = express();
app.use(express.json());
app.use(express.static(path.join(__dirname, 'public')));
app.get('/health', (_, res) => res.json({ ok: true, app: 'EARNING ZONE' }));
const port = process.env.PORT || 3000;
app.listen(port, () => console.log(`EARNING ZONE running on ${port}`));
