# EARNING ZONE — Telegram Mini App starter

This is a **starter template**, not a live earning/payment platform.

## Run locally
1. Install Node.js 18 or newer.
2. In this folder run `npm install`
3. Run `npm start`
4. Open `http://localhost:3000`

## Deploy on Render
1. Upload this folder to a GitHub repository.
2. In Render choose **New + → Web Service** and connect that repository.
3. Runtime: Node. Build command: `npm install`. Start command: `npm start`.
4. Add a custom domain or use the Render URL.

## Telegram connection
In BotFather, configure the Mini App menu button with the deployed HTTPS URL. Keep the bot token private and store it only as a server environment variable when a Telegram bot backend is added.

## Before real launch
Add a server-side database, Telegram `initData` signature validation, secure admin authorization, task-proof review, audit logs, rate limits, privacy/terms pages, and a compliant payment provider. Never trust balance or admin status sent by the browser. Do not fund commissions from later users' deposits or promise guaranteed returns.
